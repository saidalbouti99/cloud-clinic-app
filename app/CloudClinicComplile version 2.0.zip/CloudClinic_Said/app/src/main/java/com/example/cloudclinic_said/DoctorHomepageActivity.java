package com.example.cloudclinic_said;

import androidx.appcompat.app.AppCompatActivity;
import androidx.viewpager.widget.ViewPager;

import android.os.Bundle;
import android.widget.Button;

import com.example.cloudclinic_said.adapter.DeviceFragmentPagerAdapter;
import com.google.android.material.tabs.TabLayout;

public class DoctorHomepageActivity extends AppCompatActivity {
    TabLayout tabLayout;
    ViewPager viewPager;
    Button btn_upcoming_appointment;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_doctor_homepage);
        tabLayout=findViewById(R.id.tabs_doctor);
        viewPager=findViewById(R.id.view_pager_doctor);
//        setSupportActionBar(toolbar);

        setupViewPager();
        tabLayout.getTabAt(0).setIcon(R.drawable.ic_home_black_24dp);
        tabLayout.getTabAt(1).setIcon(R.drawable.ic_history_black_24dp);

    }

    private void setupViewPager(){
        DeviceFragmentPagerAdapter adapter=new DeviceFragmentPagerAdapter(getSupportFragmentManager());
        adapter.addFrag(new AppointmentFragment(),"Appointment");
        adapter.addFrag(new SettingFragment(),"Setting");


        viewPager.setAdapter(adapter);
        tabLayout.setupWithViewPager(viewPager);
    }
}
