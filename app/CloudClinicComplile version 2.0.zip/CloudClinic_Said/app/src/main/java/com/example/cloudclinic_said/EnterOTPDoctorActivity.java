package com.example.cloudclinic_said;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class EnterOTPDoctorActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_enter_otpdoctor);
        final Button btn_verify_otp=findViewById(R.id.btn_verifyOtp);

        btn_verify_otp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent verifyIntent=new Intent(EnterOTPDoctorActivity.this,OTPSuccessDoctorActivity.class);
                startActivity(verifyIntent);
            }
        });
    }
}
