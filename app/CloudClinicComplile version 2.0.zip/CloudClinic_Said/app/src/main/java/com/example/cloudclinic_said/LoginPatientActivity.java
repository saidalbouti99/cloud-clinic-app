package com.example.cloudclinic_said;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class LoginPatientActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login_patient);
        Button btn_login_patient=findViewById(R.id.btn_login_patient);
        TextView tv_signup_patient=findViewById(R.id.tv_signup_patient);

        btn_login_patient.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                Intent intentLogin=new Intent(LoginPatientActivity.this)
            }
        });

        tv_signup_patient.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent signupIntent=new Intent(LoginPatientActivity.this,SignupAsPatientActivity.class);
                startActivity(signupIntent);
            }
        });
    }
}
