package com.example.cloudclinic_said;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;

import com.example.cloudclinic_said.adapter.PendingAppointmentDoctorReccylerViewAdapter;

import java.util.ArrayList;
import java.util.List;

public class UpcomingAppointmentDoctorActivity extends AppCompatActivity {
    LinearLayoutManager linearLayoutManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_upcoming_appointment_doctor);
        ImageButton btn_back=findViewById(R.id.btn_back_upcoming_appointment);

        RecyclerView recyclerView=findViewById(R.id.recycler_view_pending_doctor);
        linearLayoutManager= new LinearLayoutManager(UpcomingAppointmentDoctorActivity.this);
        recyclerView.setLayoutManager(linearLayoutManager);


        btn_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent backIntent=new Intent(UpcomingAppointmentDoctorActivity.this,AppointmentFragment.class);
                startActivity(backIntent);
            }
        });

        List<PendingDoctorClass> allAppointmentPending= getAllAppointmentPending();
        PendingAppointmentDoctorReccylerViewAdapter pendingAppointmentDoctorReccylerViewAdapter= new PendingAppointmentDoctorReccylerViewAdapter(UpcomingAppointmentDoctorActivity.this,allAppointmentPending);
        recyclerView.setAdapter(pendingAppointmentDoctorReccylerViewAdapter);

    }
    private  List<PendingDoctorClass> getAllAppointmentPending(){
        List<PendingDoctorClass> allAppointmentP=new ArrayList<PendingDoctorClass>();
        allAppointmentP.add(new PendingDoctorClass("AP001","Video Call","Flu","20 June 2020","10:30am",true));
        allAppointmentP.add(new PendingDoctorClass("AP002","Voice Call","Cough","22 June 2020","11:30am",true));
        allAppointmentP.add(new PendingDoctorClass("AP003","Video Call","Itchy Skin","21 June 2020","4:30pm",true));

        return allAppointmentP;

    }
}
