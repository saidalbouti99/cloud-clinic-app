package com.example.cloudclinic_said;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class TAC_Doctor_Activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tac__doctor_);
        final Button btn_generateOTP=findViewById(R.id.btn_generateOtp_doctor);

        btn_generateOTP.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent generateIntent=new Intent(TAC_Doctor_Activity.this,EnterOTPDoctorActivity.class);
                startActivity(generateIntent);
            }
        });
    }
}
