package com.example.cloudclinic_said;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class LoginDoctorActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login_doctor);
        Button btn_login_doctor=findViewById(R.id.btn_login_doctor);
        TextView tv_first_time_login_doctor=findViewById(R.id.tv_first_time_login_doctor);

        btn_login_doctor.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent loginIntent=new Intent(LoginDoctorActivity.this,DoctorHomepageActivity.class);
                startActivity(loginIntent);
            }
        });

        tv_first_time_login_doctor.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent firsLoginIntent=new Intent(LoginDoctorActivity.this,SignupDoctorActivity.class);
                startActivity(firsLoginIntent);
            }
        });
    }
}
