package com.example.cloudclinic_said;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class SignupAsPatientActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup_as_patient);
        Button btn_signup_patient=findViewById(R.id.btn_signup_patient_signup);

        btn_signup_patient.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
        //                Intent signupIntent=new Intent(SignupAsPatientActivity.this)
            }
        });
    }
}
