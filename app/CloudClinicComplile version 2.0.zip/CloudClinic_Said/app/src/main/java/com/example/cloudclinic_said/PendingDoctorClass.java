package com.example.cloudclinic_said;

public class PendingDoctorClass {
    private String AppointmentID;
    private String AppointmentType;

    private String AppointmentSymptoms;
    private String AppointmentDate;
    private String AppointmentTime;
    private boolean AppointmentAccepted;

    public PendingDoctorClass(String appointmentID, String appointmentType, String appointmentSymptoms, String appointmentDate, String appointmentTime, boolean appointmentAccepted) {
        AppointmentID = appointmentID;
        AppointmentType = appointmentType;
        AppointmentSymptoms = appointmentSymptoms;
        AppointmentDate = appointmentDate;
        AppointmentTime = appointmentTime;
        AppointmentAccepted = appointmentAccepted;


    }

    public String getAppointmentID() {
        return AppointmentID;
    }

    public void setAppointmentID(String appointmentID) {
        AppointmentID = appointmentID;
    }

    public String getAppointmentType() {
        return AppointmentType;
    }

    public void setAppointmentType(String appointmentType) {
        AppointmentType = appointmentType;
    }

    public String getAppointmentSymptoms() {
        return AppointmentSymptoms;
    }

    public void setAppointmentSymptoms(String appointmentSymptoms) {
        AppointmentSymptoms = appointmentSymptoms;
    }

    public String getAppointmentDate() {
        return AppointmentDate;
    }

    public void setAppointmentDate(String appointmentDate) {
        AppointmentDate = appointmentDate;
    }

    public String getAppointmentTime() {
        return AppointmentTime;
    }

    public void setAppointmentTime(String appointmentTime) {
        AppointmentTime = appointmentTime;
    }

    public boolean isAppointmentAccepted() {
        return AppointmentAccepted;
    }

    public void setAppointmentAccepted(boolean appointmentAccepted) {
        AppointmentAccepted = appointmentAccepted;
    }
}
